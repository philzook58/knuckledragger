"""
Facilities for pretty printing and calling external solvers

Vampire and E prover are included in the ``solvers`` extra.

To install extra solvers, run either:
```
python3 -m kdrag.solvers install # install extra solvers
```

or from project root run

```
./install.sh # install extra solvers
```

"""

import kdrag as kd
import kdrag.smt as smt
from kdrag.printers.tptp import (
    expr_to_tptp,
    sort_to_tptp,
    mangle_decl,
    validate_names,
    identifier,
)
from kdrag.printers.smtlib import (
    expr_to_smtlib,
    predefined_names,
    smtlib_problem,
)
import subprocess
import os
import logging
import shutil
import re
from typing import Optional
import urllib.request
import kdrag.printers.lean as lean
import json
import hashlib
from importlib.metadata import distribution
import tempfile

logger = logging.getLogger("knuckledragger")


def binpath(cmd):
    return os.path.join(os.path.dirname(__file__), cmd)


def download(url, filename, checksum=None) -> bool:
    """Download once, validating SHA-256 when a checksum is supplied."""
    path = binpath(filename)

    def checkhash():
        with open(path, "rb") as f:
            digest = hashlib.file_digest(f, "sha256")
            return digest.hexdigest() == checksum

    if os.path.exists(path) and (checksum is None or checkhash()):
        return False
    print("Downloading", url, "to", path, "This may take a few minutes...")
    urllib.request.urlretrieve(
        url,
        path,
    )
    if checksum is not None and not checkhash():
        raise Exception("Checksum mismatch for downloaded file", filename)
    return True


def install_solvers():
    print("Installing solvers")
    subprocess.run(["bash", binpath("install.sh")], check=True)


def run(cmd, args, **kwargs):
    if cmd in ("vampire", "vampire-ho"):
        from vampire import vampire_path

        path = vampire_path
    else:
        path = binpath(cmd)
    return subprocess.run([path] + args, **kwargs)


# (declare-datatypes ((EPosReal 0)) (((real (val Real)) (inf))))


class BaseSolver:
    x, y, z = smt.Reals("x y z")
    n, m, k = smt.Ints("n m k")
    a, b, c = smt.Bools("a b c")
    predefined = [
        # smt.Function("abs", smt.RealSort(), smt.RealSort()),
        smt.And(a, b).decl(),
        smt.Or(a, b).decl(),
        smt.Not(a).decl(),
        smt.Implies(a, b).decl(),
        (n - m).decl(),
        (n + m).decl(),
        (n * m).decl(),
        (n == m).decl(),
        (n <= m).decl(),
    ]
    predefined_sorts = [
        "Int",
        "Real",
        "Bool",
    ]

    def __init__(self):
        self.adds = []
        self.assert_tracks = []
        self.options: dict = {"lambda_lift": True}
        self.res: Optional[subprocess.CompletedProcess] = None

    def add(self, thm: smt.BoolRef | list[smt.BoolRef]):
        if isinstance(thm, list):
            for t in thm:
                assert isinstance(t, smt.BoolRef)
                self.add(t)
        else:
            assert isinstance(thm, smt.BoolRef)
            if self.options["lambda_lift"]:

                def multi_domain(sort):
                    return isinstance(sort, smt.ArraySortRef) and (
                        len(smt.domains(sort)) > 1
                        or multi_domain(sort.domain())
                        or multi_domain(sort.range())
                    )

                for term in kd.utils.subterms(thm, into_binder=True):
                    if isinstance(term, smt.QuantifierRef) and term.is_lambda():
                        continue
                    sorts = [term.sort()]
                    if isinstance(term, smt.QuantifierRef):
                        sorts.extend(term.var_sort(i) for i in range(term.num_vars()))
                    if any(multi_domain(sort) for sort in sorts):
                        raise NotImplementedError(
                            "Currying multi-domain arrays requires rewriting their signatures",
                            term,
                        )
                thm1 = kd.utils.curry_arrays(thm)
                thm1, extra = kd.utils.lambda_lift(thm1)
                assert isinstance(thm1, smt.BoolRef)
                thm = thm1
                self.adds.extend(extra)
            self.adds.append(thm)

    def assert_and_track(self, thm: smt.BoolRef, name: str):
        assert isinstance(thm, smt.BoolRef)
        self.assert_tracks.append((thm, name))

    def sexpr(self):
        s = smt.Solver()
        for thm in self.adds:
            s.add(thm)
        for thm, name in self.assert_tracks:
            s.assert_and_track(thm, name)
        return s.sexpr()

    def check(self):
        raise NotImplementedError

    def unsat_core(self):
        raise NotImplementedError

    def proof(self) -> object:
        if self.res is None:
            raise Exception("No proof available")
        return getattr(self.res, "stdout")

    def set(self, option, value):
        self.options[option] = value

    def write_tptp(self, filename, format="thf"):
        assert format in ["thf", "tff", "fof"]
        logging.info("Writing TPTP file to %s", filename)
        with open(filename, "w") as fp:
            fp.write("% TPTP file generated by Knuckledragger\n")

            # Gather up all datatypes and function symbols
            predefined = set()
            declset = collect_decls(
                self.adds + [thm for thm, name in self.assert_tracks]
            )
            sortset = collect_sorts(
                self.adds + [thm for thm, name in self.assert_tracks]
            )
            user_decls = {
                d
                for d in declset
                if smt.is_uninterp(d) or smt.is_constructor(d) or smt.is_accessor(d) or smt.is_recognizer(d)
            }
            validate_names(user_decls, sortset)
            if format == "fof":
                if len(sortset) != 2:
                    raise Exception(
                        "fof format only supports Bool and a single other sort", sortset
                    )
            else:
                # Write sorts in TPTP THF format
                for sort in sortset:
                    # Write sort declarations (only for user-defined sorts)
                    name = sort.name()
                    if not (smt.is_int_sort(sort) or smt.is_real_sort(sort) or smt.is_bool_sort(sort)):
                        if format != "fof":
                            fp.write(
                                f"{format}({name.lower()}_type, type, {sort_to_tptp(sort)} : $tType ).\n"
                            )
                # Declare all function symbols in TPTP THF format
                fp.write("% Declarations\n")
                for f in user_decls:
                    if f not in predefined:
                        if f.arity() == 0:
                            fp.write(
                                f"{format}(decl_{f.get_id()}_type, type, {mangle_decl(f)} : {sort_to_tptp(f.range())} ).\n"
                            )
                        else:
                            joiner = " > " if format == "thf" else " * "
                            dom_tptp = joiner.join(
                                [sort_to_tptp(f.domain(i)) for i in range(f.arity())]
                            )
                            fp.write(
                                f"{format}(decl_{f.get_id()}_type, type, {mangle_decl(f)} : {dom_tptp} > {sort_to_tptp(f.range())}).\n"
                            )

            # Write axioms and assertions in TPTP THF format
            fp.write("% Axioms and assertions\n")
            for i, e in enumerate(self.adds):
                fp.write(
                    f"{format}(ax_{i}, axiom, {expr_to_tptp(e, format=format)}).\n"
                )
            for thm, name in self.assert_tracks:
                fp.write(
                    f"{format}({identifier(name)}, axiom, {expr_to_tptp(thm, format=format)}).\n"
                )
            # fp.write("tff(goal, conjecture, $false).\n")

            fp.flush()

    def check_tptp_status(self, res):
        if b"SZS status Unsatisfiable" in res:
            self.status = smt.unsat
            return smt.unsat
        elif b"SZS status Satisfiable" in res:
            self.status = smt.sat
            return smt.sat
        elif any(
            b"SZS status " + status in res
            for status in (b"GaveUp", b"Timeout", b"ResourceOut", b"Incomplete")
        ):
            self.status = smt.unknown
            return smt.unknown
        else:
            return smt.unknown

    def write_smt(self, fp):
        fp.write(smtlib_problem(self.adds + [thm for thm, name in self.assert_tracks]))


def collect_sorts(exprs) -> set[smt.SortRef]:
    sorts = set()
    for thm in exprs:
        todo = list(kd.utils.sorts(thm))
        while len(todo) > 0:
            sort = todo.pop()
            if sort not in sorts:
                if isinstance(sort, smt.ArraySortRef):
                    todo.append(sort.domain())
                    todo.append(sort.range())
                else:
                    sorts.add(sort)
    return sorts


def collect_decls(exprs) -> set[smt.FuncDeclRef]:
    decls = set()
    for thm in exprs:
        decls.update(kd.utils.decls(thm))
    return decls


def smt2tptp(smt_filename, outfile, format="tff"):
    constraints = smt.parse_smt2_file(smt_filename)
    solver = BaseSolver()
    for c in constraints:
        solver.add(c)
    solver.write_tptp(outfile, format=format)


def tptp2smt(tptp_filename):
    res = run(
        "TPTP4X/tptp4X", ["-f", "smt2", tptp_filename], capture_output=True, check=True
    )
    return smt.parse_smt2_string(res.stdout)


class VampireSolver(BaseSolver):
    def __init__(self):
        from vampire import vampire_path

        super().__init__()
        self.set("solver_path", vampire_path)
        self.set("format", "smtlib2")
        self.set("timeout", 1000)

    def check(self):
        with tempfile.TemporaryDirectory(prefix="kdrag-vampire-") as directory:
            filename = os.path.join(directory, "problem")
            if self.options["format"] == "smtlib2":
                with open(filename, "w") as fp:  # tempfile.NamedTemporaryFile()
                    self.write_smt(fp)
                    fp.write("(check-sat)\n")
                    fp.flush()
                cmd = [
                    self.options["solver_path"],
                    fp.name,
                    "--mode",  # This adds portfolio mode, but it was slower. Maybe more useful for hard questions?
                    "casc",
                    "--intent",
                    "unsat",
                    "--input_syntax",
                    "smtlib2",
                    # "--ignore_unrecognized_logic", "on",
                    # "--proof_extra" "fast" / "full"
                    # "--latex_output" "/tmp/vampire.tex"
                ]
            elif self.options["format"] in ["fof", "tff", "thf"]:
                self.write_tptp(filename, format=self.options["format"])
                cmd = [
                    self.options["solver_path"],
                    filename,
                    "--mode",
                    "casc",
                    "--input_syntax",
                    "tptp",
                ]
            else:
                raise Exception(
                    "Unsupported format for Vampire", self.options["format"]
                )
            if "timeout" in self.options:
                cmd.extend(
                    ["-t", str(max(1, (self.options["timeout"] + 99) // 100)) + "d"]
                )
            if len(self.assert_tracks) > 0:
                cmd.extend(["--output_mode", "ucore"])
            else:
                cmd.extend(["--output_mode", "smtcomp"])

            self.res = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
            res = self.res.stdout
            lines = {line.strip() for line in res.splitlines()}
            if self.res.returncode == 0:
                if b"unsat" in lines or b"Unsatisfiable" in re.findall(
                    rb"^% SZS status (\w+)", res, re.MULTILINE
                ):
                    self.status = smt.unsat
                    return self.status
                if b"sat" in lines or b"Satisfiable" in re.findall(
                    rb"^% SZS status (\w+)", res, re.MULTILINE
                ):
                    return smt.sat
            return smt.unknown

    def query(self, q):
        with open("/tmp/vampire.smt2", "w") as fp:  # tempfile.NamedTemporaryFile()
            # TODO: Since some sorts may be needed to be collected from the query, we're missing them
            # However, if you introduce new stuff in the query, that's kind of weird. Still useful possibly without fixing this.
            # self.add(smt.Not(q))
            self.write_smt(fp)
            # self.adds.pop()
            fp.write(f"(assert-not {expr_to_smtlib(q)})")
            fp.write("(check-sat)\n")
            fp.flush()
            cmd = [
                self.options["solver_path"],
                fp.name,
                "--mode",
                "casc",
                "--question_answering",
                "synthesis",  # "answer_literal"
                "--proof",
                "off",
                "--input_syntax",
                "smtlib2",  # "--ignore_unrecognized_logic", "on",
            ]
            if "timeout" in self.options:
                cmd.extend(["-t", str(self.options["timeout"] // 100) + "d"])

            self.res = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
        res = self.res.stdout
        return [
            line for line in res.decode().splitlines() if "% SZS answers Tuple" in line
        ]

    def unsat_core(self):
        assert self.status == smt.unsat and self.res is not None
        cores = (
            self.res.stdout.decode()
            .split("unsat\n")[1]
            .replace("(", "")
            .replace(")", "")
            .split()
        )
        cores = [smt.Bool(core) for core in cores]
        return cores

    def proof(self):
        res = []
        assert self.res is not None
        # https://github.com/teorth/equational_theories/blob/main/equational_theories/Generated/VampireProven/src/vampire_proofs_cyc.py
        for eqnum, statement, reason in re.findall(
            r"(\d+)\. ([^[]+) \[([^\]]+)\]", self.res.stdout.decode()
        ):
            res.append((int(eqnum), statement, reason))  # TODO: Deeper parsing
        return res


class CVC5Solver(BaseSolver):
    """

    >>> solver = CVC5Solver()
    >>> x, y = smt.Reals("x y")
    >>> solver.add(x > x - 1)
    >>> solver.check()
    sat
    >>> solver.add(x > x + 1)
    >>> solver.check()
    unsat
    """

    def __init__(self):
        super().__init__()

    def check(self):
        with tempfile.TemporaryDirectory(prefix="kdrag-cvc5-") as directory:
            filename = os.path.join(directory, "problem.smt2")
            with open(filename, "w") as fp:
                self.write_smt(fp)
                fp.write("(check-sat)\n")
            cmd = ["cvc5", "--lang", "smt2.6", filename]
            if "timeout" in self.options:
                cmd.extend(["--tlimit-per", str(max(1, self.options["timeout"]))])
            self.res = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
        if self.res.returncode == 0:
            lines = {line.strip() for line in self.res.stdout.splitlines()}
            for word, status in (
                (b"unsat", smt.unsat),
                (b"sat", smt.sat),
                (b"unknown", smt.unknown),
            ):
                if word in lines:
                    return status
        return smt.unknown


class VampireTHFSolver(VampireSolver):
    def __init__(self):
        super().__init__()
        self.set("format", "thf")


class EProverSolver(BaseSolver):
    def __init__(self):
        from eprover import eprover_path

        self.solver_path = eprover_path
        super().__init__()
        self.options["format"] = "tff"

    def check(self):
        with tempfile.TemporaryDirectory(prefix="kdrag-eprover-") as directory:
            filename = os.path.join(directory, "problem.p")
            self.write_tptp(filename, format=self.options["format"])
            cmd = [self.solver_path, "--auto-schedule=8", filename]
            if "timeout" in self.options:
                cmd.append(
                    "--cpu-limit="
                    + str(max(1, (self.options["timeout"] + 999) // 1000))
                )
            self.res = subprocess.run(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE
            )
        if self.res.returncode not in (0, 1):
            return smt.unknown
        if b"SZS status Unsatisfiable" in self.res.stdout and self.res.returncode != 0:
            return smt.unknown
        return self.check_tptp_status(self.res.stdout)


class EProverTHFSolver(EProverSolver):
    def __init__(self):
        super().__init__()
        self.options["format"] = "thf"


class ZipperpositionSolver(BaseSolver):
    def __init__(self):
        super().__init__()

    def check(self):
        filename = "/tmp/zipperposition.p"
        self.write_tptp(filename)
        cmd = [
            "zipperposition",
            "--mode",
            "best",
            filename,
        ]
        if "timeout" in self.options:
            cmd.extend(["--timeout", str(self.options["timeout"] // 1000 + 1)])

        self.res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return self.check_tptp_status(self.res.stdout)


class LeoIIISolver(BaseSolver):
    def check(self):
        filename = "/tmp/leo3.p"
        self.write_tptp(filename)
        cmd = [
            "java",
            "-jar",
            binpath("leo3.jar"),
            filename,
        ]
        if "timeout" in self.options:
            cmd.extend(["-t", str(self.options["timeout"] // 1000 + 1)])

        self.res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        return self.check_tptp_status(self.res.stdout)


class TweeSolver(BaseSolver):
    def check(self):
        filename = "/tmp/twee.p"

        self.write_tptp(filename, format="tff")
        # cmd = [binpath("vampire"), "--mode", "clausify", filename]
        # with open("/tmp/twee2.p", "w") as fp:
        #    res = subprocess.run(cmd, stdout=fp, stderr=subprocess.PIPE)
        cmd = [
            binpath("twee"),
            "--tstp",
            "/tmp/twee.p",
        ]
        # if "timeout" in self.options:
        #    cmd.extend(["-t", str(self.options["timeout"] // 1000 + 1)])

        self.res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        return self.check_tptp_status(self.res.stdout)


def _kissat_path() -> str:
    return str(distribution("passagemath-kissat").locate_file("sage_wheels/bin/kissat"))


class SATSolver:
    def __init__(self):
        self.G = smt.Goal()
        self.cmd = [_kissat_path(), "--relaxed"]

    def add(self, clause):
        self.G.add(clause)

    def check(self, debug=False):
        t = smt.Then("simplify", "bit-blast", "tseitin-cnf")
        c = t(self.G)
        assert len(c) == 1
        with open("/tmp/sat.cnf", "w") as f:
            f.write(c[0].dimacs())
            f.flush()
        self.res = subprocess.run(self.cmd + ["/tmp/sat.cnf"], capture_output=True)
        res = self.res.stdout.decode()
        if "s SATISFIABLE" in res:
            return smt.sat
        elif "s UNSATISFIABLE" in res:
            return smt.unsat
        else:
            return smt.unknown


class NanoCopISolver(BaseSolver):
    def check(self):
        filename = "/tmp/nanocopi.p"
        self.write_tptp(filename, format="fof")
        cmd = [
            binpath("nanoCoP-i20/nanocopi.sh"),
            filename,
        ]
        if "timeout" in self.options:
            cmd.extend(str(self.options["timeout"] // 1000 + 1))

        self.res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if b"intuitionistically Satisfiable" in self.res.stdout:
            return smt.sat
        elif b"intuitionistically Unsatisfiable" in self.res.stdout:
            return smt.unsat
        else:
            return smt.unknown


class MultiSolver(BaseSolver):
    solver_classes: list[type] = [
        VampireTHFSolver,
        EProverTHFSolver,
        LeoIIISolver,
    ]
    if shutil.which("zipperposition") is not None:
        solver_classes.append(ZipperpositionSolver)

    def __init__(self, solvers=None, strict=False):
        super().__init__()
        if solvers is not None:
            self.solvers = solvers
        else:
            self.solvers = [s() for s in self.solver_classes]

    def add(self, thm):
        for s in self.solvers:
            s.add(thm)

    def assert_and_track(self, thm, name):
        for s in self.solvers:
            s.assert_and_track(thm, name)

    def set(self, option, value):
        for s in self.solvers:
            s.set(option, value)

    def check(self, strict=False):
        # TODO: This is working very sporadically
        """
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=len(self.solvers)
        ) as executor:
                results = list(executor.map(lambda s: s.check(), self.solvers))
        """
        results = list(map(lambda s: s.check(), self.solvers))
        if smt.sat in results and smt.unsat in results:
            raise Exception(
                "Inconsistent results from solvers",
                {s.__class__.__name__: res for s, res in zip(self.solvers, results)},
            )
        if strict:
            if not all(r == results[0] for r in results):
                raise Exception(
                    "Inconsistent results from solvers",
                    {
                        s.__class__.__name__: res
                        for s, res in zip(self.solvers, results)
                    },
                )
        if smt.unsat in results:
            return smt.unsat
        elif smt.sat in results:
            return smt.sat
        else:
            return smt.unknown


class LeanSolver(BaseSolver):
    def __init__(self):
        self.imports = []
        self.tactic = "grind"  # can replace by bv_decide or even tactic script. The string is just spliced in.\
        # Lean version needs to be explicitly picked or else elan will check for version which is very slow.
        self.lean_version = "4.22.0-rc3"
        super().__init__()

    def check(self):
        with open("/tmp/test.lean", "w") as f:
            for imp in self.imports:
                f.write(f"import {imp}\n")
            f.write("set_option linter.unusedVariables false\n")  # To remove an warning
            f.write("set_option grind.warning false\n")
            predefined = set()
            # make inductive datatype definitions
            for sort in collect_sorts(
                self.adds + [thm for thm, name in self.assert_tracks]
            ):
                if isinstance(sort, smt.DatatypeSortRef):
                    f.write(lean.of_datatype(sort))
                    f.write("open " + sort.name() + "\n")
                    for n in range(sort.num_constructors()):
                        cons = sort.constructor(n)
                        predefined.add(cons)
                        for i in range(cons.arity()):
                            f.write(lean.accessor_def(sort, n, i))
                            predefined.add(sort.accessor(n, i))
                elif sort.name() not in self.predefined_sorts:
                    f.write(lean.sort_axiom(sort))
            # state axioms for all non predefined declarations
            for decl in collect_decls(
                self.adds + [thm for thm, name in self.assert_tracks]
            ):
                if decl not in predefined and decl.name() not in predefined_names:
                    f.write(lean.decl_axiom(decl))
            # Make the actual goal
            f.write("theorem mythm : Not (True ")
            for expr in self.adds + [thm for thm, name in self.assert_tracks]:
                f.write("  /\\ \n")
                f.write(lean.of_expr(expr))
            f.write(f") := by {self.tactic}\n")
            f.write("#check mythm\n")
            f.flush()
        result = subprocess.run(
            ["elan", "run", self.lean_version, "lean", "--json", "/tmp/test.lean"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            return smt.unknown
        else:
            result = json.loads(result.stdout)
            assert result["severity"] == "information"
            assert "mythm" in result["data"]
            return smt.unsat
