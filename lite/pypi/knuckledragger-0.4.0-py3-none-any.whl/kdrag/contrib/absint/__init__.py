"""
Abstract interpretation
"""
