"""
SortDispatch system for z3 sort based dispatch akin to `functools.singledispatch`.

The `SortDispatch` system enables z3 sort based dispatch akin to ` functools.singledispatch`.
This is the mechanism for operator overloading in knuckledragger.

A special overloadable operation is the "well-formed" predicate `wf`.
Using the QForAll and QExists quantifiers will automatically insert `wf` calls for the appropriate sorts.
In this way, we can achieve an effect similar to refinement types.

Importing this module will add some syntactic sugar to smt.

- Expr overload by single dispatch
- Bool supports `&`, `|`, `~`
- Sets support `|`, `&`, `~`, `-`, `<=`, `>=`
- Sorts supports `>>` for ArraySort
"""

from collections.abc import Callable

import kdrag.smt as smt
import kdrag as kd
from kdrag.cast import cast


smt.SortRef.__rshift__ = lambda self, other: smt.ArraySort(self, other)  # type: ignore[ty:missing-attribute]

smt.ArrayRef.__call__ = lambda self, *arg: self[arg]


def compose(f: smt.FuncDeclRef, g: smt.FuncDeclRef) -> smt.FuncDeclRef:
    """
    >>> f = smt.Function("f", smt.IntSort(), smt.RealSort())
    >>> g = smt.Function("g", smt.BoolSort(), smt.IntSort())
    >>> f @ g
    Lambda(x, f(g(x)))
    """
    A = g.domain(0)
    x = smt.Const("x", A)
    return smt.Lambda([x], f(g(x)))


smt.FuncDeclRef.__matmul__ = lambda f, g: compose(f, g)  # type: ignore


def quantifier_call(self, *args):
    """
    Instantiate a quantifier. This does substitution
    >>> x,y = smt.Ints("x y")
    >>> smt.Lambda([x,y], x + 1)(2,3)
    2 + 1

    To apply a Lambda without substituting, use square brackets
    >>> smt.Lambda([x,y], x + 1)[2,3]
    Select(Lambda([x, y], x + 1), 2, 3)
    """
    if self.num_vars() != len(args):
        raise TypeError("Wrong number of arguments", self, args)
    terms = [
        arg if isinstance(arg, smt.ExprRef) else self.var_sort(i).cast(arg)
        for i, arg in enumerate(args)
    ]
    return smt.substitute_body(self, *terms)


smt.QuantifierRef.__call__ = quantifier_call


def Image(f: Callable[..., smt.ExprRef], *args, **kwargs) -> smt.QuantifierRef:
    """Image of f over set operands, holding scalar operands fixed.

    Each set operand contributes an independent existential witness, even when
    the same set is supplied twice. At least one operand must be a set.

    >>> A, B = smt.Consts("A B", smt.SetSort(smt.IntSort()))
    >>> x, y, z = smt.Ints("x y z")
    >>> kd.prove(Image(lambda x, y: x + y, A, B)[z] ==
    ...          smt.Exists([x, y], A[x], B[y], z == x + y))
    |= ...
    """
    vs = []
    members = []
    elements = []
    for arg in args:
        if smt.is_set(arg):
            x = smt.FreshConst(arg.sort().domain(), prefix="x")
            vs.append(x)
            members.append(arg(x))
            elements.append(x)
        else:
            elements.append(arg)
    if not vs:
        raise ValueError("Image requires at least one set operand")
    value = f(*elements, **kwargs)
    z = smt.FreshConst(value.sort(), prefix="z")
    return smt.Lambda(z, smt.Exists(vs, smt.And(*members, smt.Eq(z, value))))


class SortDispatch:
    """
    Sort dispatch is modeled after functools.singledispatch
    It allows for dispatching on the sort of the first argument.

    Registered methods, default, and default_factory take precedence over
    set_default, which handles unary Boolean arrays before automatic lifting.
    Otherwise, operations on sets form the image of the element operation.
    Each set operand contributes an independent existential witness; other
    operands are held fixed. Non-set arrays still use pointwise lifting.
    Lifting a predicate over sets produces a set of Booleans, not a quantified
    assertion. Native set operations and comparisons use set_default instead.

    >>> my_func = SortDispatch(name="my_func")
    >>> my_func.register(smt.IntSort(), lambda x: x + 1)
    >>> my_func.register(smt.BoolSort(), lambda x: smt.Not(x))
    >>> my_func(smt.IntVal(3))
    3 + 1
    >>> my_func(smt.BoolVal(True))
    Not(True)
    """

    def __init__(
        self,
        name=None,
        default=None,
        default_factory=None,
        set_default=None,
    ):
        self.methods = {}
        self.default = default
        self.name = name
        self.default_factory = default_factory
        self.set_default = set_default

    def register(self, sort, func):
        self.methods[sort] = func

    def __getitem__(self, sort):
        return self.methods[sort]

    def __contains__(self, sort):
        return sort in self.methods

    def declare(self, *sorts):
        """
        Declare a name

        >>> MySort = smt.DeclareSort("MySort124")
        >>> or_.declare(MySort, MySort, MySort)
        MySort124.or_
        """
        T = sorts[0]
        f = kd.kernel.declare(T.name() + "." + self.name, *sorts)
        self.register(T, f)
        return f

    def __call__(self, *args, **kwargs):
        """

        >>> x = smt.Int("x")
        >>> _ = smt.Lambda([x], x > 0) & smt.Lambda([x], x > 1)
        >>> foo = SortDispatch("foo")
        >>> foo.register(smt.IntSort(), lambda x: x + 1)
        >>> foo(x)
        x + 1
        >>> z = smt.Array("z", smt.RealSort(), smt.IntSort())
        >>> foo(z)
        Lambda(x0!..., z[x0!...] + 1)
        >>> smt.Lambda([x], x) + smt.Lambda([x], x)
        Lambda(x0!..., x0!... + x0!...)
        >>> smt.Lambda([x], x) + 1
        Lambda(x0!..., x0!... + 1)
        """
        if not args:
            raise TypeError("No arguments provided")
        x0 = args[0]
        sort = args[0].sort()
        res = self.methods.get(sort)
        if res is not None:
            return res(*args, **kwargs)
        elif self.default is not None:
            return self.default(*args, **kwargs)
        elif self.default_factory is not None:
            res = self.default_factory(sort)
            self.register(sort, res)
            return res(*args, **kwargs)
        elif smt.is_set(x0):
            # Sets are unary Boolean arrays. Prefer native set operations to
            # lifting through membership, while preserving explicit overrides.
            if self.set_default is not None:
                return self.set_default(*args, **kwargs)
            return Image(self, *args, **kwargs)
        elif smt.is_func(x0):
            doms = smt.domains(x0)
            vs = [smt.FreshConst(d, prefix=f"x{n}") for n, d in enumerate(doms)]
            # sorts are same or attempt coerce/lift
            return smt.Lambda(
                vs,
                self(
                    *[
                        arg(*vs)
                        if isinstance(arg, smt.ExprRef) and arg.sort() == x0.sort()
                        else arg
                        for arg in args
                    ]
                ),
            )
        else:
            raise NotImplementedError(
                f"No implementation of {self.name} for sort {sort}. Register a definition via {self.name}.register({sort}, your_code)",
            )
        return res(*args, **kwargs)

    def define(self, args, body):
        """
        Shorthand to define a new function for this dispatch. Calls kdrag.define.
        Accepts a single argument or a list of arguments.
        """
        assert isinstance(self.name, str)
        if isinstance(args, smt.ExprRef):
            args = [args]
        sort = args[0].sort()
        defn = kd.define(sort.sexpr() + "." + self.name, args, body)
        self.register(sort, defn)
        return defn


def GenericDispatch(default_factory) -> SortDispatch:
    """
    A decorator version of SortDispatch with a default factory.
    This is useful for definition Sort generic definitions.

    >>> @GenericDispatch
    ... def id(sort):
    ...    x = smt.Const("x", sort)
    ...    return kd.define("id", [x], x)
    >>> id(smt.IntVal(3))
    id(3)
    """
    return SortDispatch(default_factory.__name__, default_factory=default_factory)


call = SortDispatch(name="call")
"""Sort based dispatch for `()` call syntax"""
smt.ExprRef.__call__ = lambda self, *args, **kwargs: call(self, *args, **kwargs)


def default_getitem(self: smt.ExprRef, ind: int) -> smt.ExprRef:
    """
    Enable indexing into the fields of a record datatype. Only works for single constructor datatypes.
    >>> kd.tuple_(smt.IntVal(3), smt.BoolVal(True))[0]
    _0(Tuple_Int_Bool(3, True))
    """
    if isinstance(self, smt.DatatypeRef):
        sort = self.sort()
        if sort.num_constructors() != 1:
            raise TypeError("Cannot index into datatypes with multiple constructors")
        return sort.accessor(0, ind)(self)
    else:
        raise TypeError("No instance of getitem for", self)


getitem = SortDispatch(name="getitem", default=default_getitem)
"""Sort based dispatch for `[]` getitem syntax"""
smt.ExprRef.__getitem__ = lambda x, y: getitem(x, y)  # type: ignore


add = SortDispatch(name="add")
"""Sort based dispatch for `+` syntax"""
smt.ExprRef.__add__ = lambda x, y: add(x, y)  # type: ignore
# BoolRef has an __add__ method, and QuantifierRef subclasses it even though this makes no sense.
# Clearing this restores better behavior.
smt.QuantifierRef.__add__ = lambda x, y: add(x, y)  # type: ignore

_n, _m = smt.Ints("n m")
_x, _y = smt.Reals("x y")
add.register(smt.IntSort(), (_n + _m).decl())
add.register(smt.RealSort(), (_x + _y).decl())


radd = SortDispatch(name="radd")
"""Sort based dispatch for `+` syntax"""
radd.register(smt.IntSort(), (_n + _m).decl())
radd.register(smt.RealSort(), (_x + _y).decl())
# TODO: Revisit add/radd dispatch: Z3 scalar __add__ methods can raise before
# reflected dispatch runs, so x + xs misses the sequence singleton hint.
smt.ExprRef.__radd__ = lambda x, y: radd(x, y)  # type: ignore


def _seq_concat(xs: smt.SeqRef, other, prepend=False):
    """Concatenate sequences or a Python list of elements of the sequence sort."""
    seq_sort = xs.sort()
    if isinstance(other, list):
        other = cast(seq_sort, other)
    bare_element = not isinstance(other, (smt.SeqRef, str))
    if isinstance(other, smt.SeqRef):
        other_sort = other.sort()
        if other_sort != seq_sort:
            bare_element = (
                other_sort == seq_sort.basis() or seq_sort == other_sort.basis()
            )
    if bare_element:
        raise TypeError(
            "Cannot concatenate a sequence and a bare element; "
            "use [x] + xs or xs + [x] for a singleton"
        )
    return smt.Concat(other, xs) if prepend else smt.Concat(xs, other)


smt.SeqRef.__add__ = lambda xs, other: _seq_concat(xs, other)  # type: ignore
smt.SeqRef.__radd__ = lambda xs, other: _seq_concat(xs, other, prepend=True)  # type: ignore


sub = SortDispatch(name="sub", set_default=smt.SetDifference)
"""Sort based dispatch for `-` syntax"""
sub.register(smt.IntSort(), lambda x, y: x - y)
sub.register(smt.RealSort(), lambda x, y: x - y)
smt.ExprRef.__sub__ = lambda x, y: sub(x, y)  # type: ignore
smt.QuantifierRef.__sub__ = lambda x, y: sub(x, y)  # type: ignore

mul = SortDispatch(name="mul")
"""Sort based dispatch for `*` syntax"""
mul.register(smt.IntSort(), lambda x, y: x * y)
mul.register(smt.RealSort(), lambda x, y: x * y)
smt.ExprRef.__mul__ = lambda x, y: mul(x, y)  # type: ignore
smt.QuantifierRef.__mul__ = lambda x, y: mul(x, y)  # type: ignore

rmul = SortDispatch(name="rmul")
"""Sort based dispatch for `*` syntax"""
smt.ExprRef.__rmul__ = lambda x, y: rmul(x, y)  # type: ignore
rmul.register(smt.IntSort(), lambda x, y: y * x)
rmul.register(smt.RealSort(), lambda x, y: y * x)


matmul = SortDispatch(name="matmul")
"""Sort based dispatch for `@` syntax"""
smt.ExprRef.__matmul__ = lambda x, y: matmul(x, y)  # type: ignore

neg = SortDispatch(name="neg")
"""Sort based dispatch for `-` syntax"""
neg.register(smt.IntSort(), lambda x: -x)
neg.register(smt.RealSort(), lambda x: -x)
smt.ExprRef.__neg__ = lambda x: neg(x)  # type: ignore

div = SortDispatch(name="div_")
"""Sort based dispatch for `/` syntax"""
smt.ExprRef.__truediv__ = lambda x, y: div(x, y)  # type: ignore
div.register(smt.IntSort(), lambda x, y: x / y)
div.register(smt.RealSort(), lambda x, y: x / y)

and_ = SortDispatch(name="and_", set_default=smt.SetIntersect)
"""Sort based dispatch for `&` syntax"""
smt.ExprRef.__and__ = lambda x, y: and_(x, y)  # type: ignore
smt.QuantifierRef.__and__ = lambda x, y: and_(x, y)  # type: ignore
and_.register(smt.BoolSort(), smt.And)

or_ = SortDispatch(name="or_", set_default=smt.SetUnion)
"""Sort based dispatch for `|` syntax"""
smt.ExprRef.__or__ = lambda x, y: or_(x, y)  # type: ignore[ty:invalid-assignment]
smt.QuantifierRef.__or__ = lambda x, y: or_(x, y)  # type: ignore
or_.register(smt.BoolSort(), smt.Or)

invert = SortDispatch(name="invert", set_default=smt.SetComplement)
"""Sort based dispatch for `~` syntax"""
smt.ExprRef.__invert__ = lambda x: invert(x)  # type: ignore[ty:invalid-assignment]
smt.QuantifierRef.__invert__ = lambda x: invert(x)  # type: ignore
invert.register(smt.BoolSort(), smt.Not)

lt = SortDispatch(
    name="lt", set_default=lambda x, y: smt.And(smt.IsSubset(x, y), x != y)
)
"""Sort based dispatch for `<` syntax"""
smt.ExprRef.__lt__ = lambda x, y: lt(x, y)  # type: ignore[ty:invalid-assignment]
lt.register(smt.IntSort(), lambda x, y: x < y)
lt.register(smt.RealSort(), lambda x, y: x < y)
# Conceptually this kind of makes sense, but SubSet is the more natural thing.
# lt.register(smt.BoolSort(), lambda x, y: smt.And(smt.Not(x), y))


le = SortDispatch(name="le", set_default=smt.IsSubset)
"""Sort based dispatch for `<=` syntax"""
smt.ExprRef.__le__ = lambda x, y: le(x, y)  # type: ignore[ty:invalid-assignment]
le.register(smt.IntSort(), lambda x, y: x <= y)
le.register(smt.RealSort(), lambda x, y: x <= y)
# le.register(smt.BoolSort(), lambda x, y: smt.Implies(x, y))

ge = SortDispatch(
    name="ge", set_default=lambda x, y: smt.IsSubset(y, x)
)
"""Sort based dispatch for `>=` syntax"""
smt.ExprRef.__ge__ = lambda x, y: ge(x, y)  # type: ignore[ty:invalid-assignment]
ge.register(smt.IntSort(), lambda x, y: x >= y)
ge.register(smt.RealSort(), lambda x, y: x >= y)
# ge.register(smt.BoolSort(), lambda x, y: smt.Implies(y, x))

gt = SortDispatch(
    name="gt", set_default=lambda x, y: smt.And(smt.IsSubset(y, x), x != y)
)
"""Sort based dispatch for `>` syntax"""
smt.ExprRef.__gt__ = lambda x, y: gt(x, y)  # type: ignore[ty:invalid-assignment]
gt.register(smt.IntSort(), lambda x, y: x > y)
gt.register(smt.RealSort(), lambda x, y: x > y)
# gt.register(smt.BoolSort(), lambda x, y: smt.And(x, smt.Not(y)))

# contains cannot work because python demands a concrete bool.
# contains = SortDispatch(name="contains")
# smt.ExprRef.__contains__ = lambda x, y: contains(x, y)

eq = SortDispatch(name="eq", default=smt.Eq)
"""Sort based dispatch for `==` syntax"""
smt.ExprRef.__eq__ = lambda x, y: eq(x, y)  # type: ignore[ty:invalid-assignment]


ne = SortDispatch(name="ne", default=smt.NEq)
"""Sort based dispatch for `!=` syntax"""
smt.ExprRef.__ne__ = lambda x, y: ne(x, y)  # type: ignore[ty:invalid-assignment]

wf = SortDispatch(name="wf")
"""`wf` is a special predicate for well-formedness. It is auto inserted by QForAll and QExists."""
smt.ExprRef.wf = lambda x: wf(x)

measure = SortDispatch(name="measure")
"""`measure is an Int value associated with an ExprRef for use in defining well-founded recursion."""
# smt.ExprRef.measure = lambda x: measure(x)
measure.register(smt.IntSort(), lambda x: smt.Abs(x))
measure.register(smt.BoolSort(), lambda x: smt.If(x, smt.IntVal(1), smt.IntVal(0)))

choose = SortDispatch(name="choose")
"""Sort based dispatch for Hilbert choice operator."""
# smt.ExprRef.choose = lambda P: choose(P)

# These are of questionable utility, but conceptually should be here.
forall = SortDispatch(name="forall")
"""Sort based dispatch for `ForAll` quantifier."""
# smt.ExprRef.forall = lambda vs, body: forall(vs, body)

exists = SortDispatch(name="exists")
"""Sort based dispatch for `Exists` quantifier."""
# smt.ExprRef.exists = lambda vs, body: exists(vs, body)


def trans_factory(Tstep: smt.ArraySortRef) -> smt.FuncDeclRef:
    """
    Transitive closure

    >>> x = smt.Int("x")
    >>> trans(smt.Lambda([x], x + 1))(smt.IntVal(2), smt.IntVal(3))
    Select(Int.trans(Lambda(x, x + 1)), 2, 3)
    """
    T = Tstep.range()
    x0 = smt.Const("x", T)
    t = smt.Const("t", smt.IntSort())
    step = smt.Const("step", Tstep)
    name = T.name() + ".trans"
    trans = smt.Function(name, Tstep, T, smt.IntSort(), T)
    return kd.define(
        name,
        [step],
        smt.Lambda([x0, t], smt.If(t <= 0, x0, step(trans(step, x0, t - 1)))),
    )


trans = SortDispatch("trans", default_factory=trans_factory)


def induct_seq(a: smt.SeqRef, P) -> kd.kernel.Proof:
    """
    Empty/singleton/concatenation induction, available explicitly.

    >>> x = smt.Const("x", smt.SeqSort(smt.IntSort()))
    >>> induct_seq(x, lambda s: smt.Length(s) >= 0)
    |= Implies(And(Length(Empty(Seq(Int))) >= 0,
                ForAll(z!..., Length(Unit(z!...)) >= 0),
                ForAll([x!..., y!...],
                       Implies(Length(x!...) >= 0,
                               Implies(Length(y!...) >= 0,
                                       Length(Concat(x!..., y!...)) >=
                                       0)))),
            Length(x) >= 0)
    """
    assert isinstance(a, smt.SeqRef)
    sort = a.sort()
    T = sort.basis()
    z = smt.FreshConst(T, prefix="z")
    x, y = smt.FreshConst(sort, prefix="x"), smt.FreshConst(sort, prefix="y")
    return kd.axiom(
        smt.Implies(
            smt.And(
                P(smt.Empty(sort)),
                QForAll([z], P(smt.Unit(z))),
                QForAll([x, y], P(x), P(y), P(smt.Concat(x, y))),
            ),
            # -------------------------------------------------
            P(a),
        )
    )


def induct_seq_list(x: smt.SeqRef, P) -> kd.kernel.Proof:
    """Empty/cons induction for any sequence element sort.

    >>> xs = smt.Const("xs", smt.SeqSort(smt.IntSort()))
    >>> induct(xs, lambda s: smt.Length(s) >= 0)
    |= Implies(And(Length(Empty(Seq(Int))) >= 0,
                ForAll([hd!..., tl!...],
                       Implies(Length(tl!...) >= 0,
                               Length(Concat(Unit(hd!...), tl!...)) >= 0))),
            Length(xs) >= 0)
    """
    assert isinstance(x, smt.SeqRef)
    hd = smt.FreshConst(x.sort().basis(), prefix="hd")
    tl = smt.FreshConst(x.sort(), prefix="tl")
    return kd.axiom(
        smt.Implies(
            smt.And(
                P(smt.Empty(x.sort())),
                QForAll([hd, tl], P(tl), P(smt.Unit(hd) + tl)),
            ),
            P(x),
        )
    )


def induct_default(x, P):
    if isinstance(x, smt.SeqRef):
        return induct_seq_list(x, P)
    else:
        raise NotImplementedError("No default induct implementation for sort", x.sort())


induct = SortDispatch(name="induct", default=induct_default)
"""Sort based dispatch for induction principles. Should instantiate an induction scheme for variable x and predicate P"""
smt.ExprRef.induct = lambda x, P: induct(x, P)


def induct_int(x, P):
    n = smt.FreshConst(smt.IntSort(), prefix="n")
    # P = smt.FreshConst(smt.ArraySort(Z, smt.BoolSort()), prefix="P")
    return kd.kernel.axiom(
        smt.Implies(
            smt.And(
                smt.ForAll([n], n <= 0, P(n), P(n - 1)),
                P(0),
                smt.ForAll([n], n >= 0, P(n), P(n + 1)),
            ),
            # ---------------------------------------------------
            P(x),
        ),
        by="integer_induction",
    )


induct.register(smt.IntSort(), induct_int)


to_int = SortDispatch(name="to_int")
"""Sort based dispatch for `to_int`"""
smt.ExprRef.to_int = lambda x: to_int(x)  # type: ignore

to_real = SortDispatch(name="to_real")
"""Sort based dispatch for `to_real`"""
smt.ExprRef.to_real = lambda x: to_real(x)  # type: ignore


def QImplies(*hyp_conc) -> smt.BoolRef:
    """Quantified Implies

    Shorthand for `Implies(And(hyp[0], hyp[1], ...), conc)`

    >>> x,y = smt.Ints("x y")
    >>> QImplies(x > 0, y > 0, x + y > 0)
    Implies(And(x > 0, y > 0), x + y > 0)

    """
    conc = hyp_conc[-1]
    hyps = hyp_conc[:-1]
    if len(hyps) == 0:
        raise ValueError("No hypotheses given in QImplies", conc)
    elif len(hyps) == 1:
        return smt.Implies(hyps[0], conc)
    else:
        hyp = smt.And(hyps)
        return smt.Implies(hyp, conc)


def QForAll(vs: list[smt.ExprRef], *hyp_conc) -> smt.BoolRef:
    """Quantified ForAll

    Shorthand for `ForAll(vars, Implies(hyp[0], Implies(hyp[1], ..., conc)))`.
    Use an explicit `And` to group premises.

    If variables have a property `wf` attached, this is added as a hypothesis.

    There is no downside to always using this compared to `smt.ForAll` and it can avoid some errors.

    >>> x,y = smt.Ints("x y")
    >>> QForAll([x,y], x > 0, y > 0, x + y > 0)
    ForAll([x, y], Implies(x > 0, Implies(y > 0, x + y > 0)))

    """
    assert hyp_conc
    hyps = [v.wf() for v in vs if v.sort() in wf.methods]
    return smt.ForAll(vs, *hyps, *hyp_conc)


def QExists(vs: list[smt.ExprRef], *concs0) -> smt.BoolRef:
    """Quantified Exists

    Shorthand for `ForAll(vars, And(conc[0], conc[1], ...))`

    If variables have a property `wf` attached, this is anded into the properties.
    """
    concs = [v.assumes for v in vs if v.assumes is not None]
    concs.extend([v.wf() for v in vs if v.sort() in wf.methods])
    concs.extend(concs0)
    if len(concs) == 1:
        return smt.RawExists(vs, concs[0])
    else:
        return smt.RawExists(vs, smt.And(concs))


def QLambda(xs: list[smt.ExprRef], *args):
    """
    Conditional Lambda. If conjunction of conditions are not met, returns unconstrained value.

    >>> x = smt.Int("x")
    >>> QLambda([x], x > 0, x + 1)
    Lambda(x, If(x > 0, x + 1, f!...(x)))
    >>> QLambda([x], x > 0, x < 10, x + 1)
    Lambda(x, If(And(x > 0, x < 10), x + 1, f!...(x)))
    """
    conds, body = args[:-1], args[-1]
    undef = smt.FreshFunction(*[x.sort() for x in xs], body.sort())
    if len(conds) == 0:
        return smt.Lambda(xs, body)
    elif len(conds) == 1:
        return smt.Lambda(xs, smt.If(conds[0], body, undef(*xs)))
    else:
        return smt.Lambda(xs, smt.If(smt.And(conds), body, undef(*xs)))


def ExistsUnique(v: smt.ExprRef, *concs) -> smt.BoolRef:
    """Unique Existence"""
    y: smt.ExprRef = smt.FreshConst(v.sort(), prefix="y")
    concs_y = [smt.substitute(conc, (v, y)) for conc in concs]
    return smt.And(
        QExists([v], *concs),
        QForAll([v, y], *concs, *concs_y, v == y),
    )


def cond(*cases, default=None) -> smt.ExprRef:
    """
    Helper for chained ifs defined by cases.
    Each case is a tuple of a bool condition and a term.
    If default is not given, a check is performed for totality.

    >>> x = smt.Int("x")
    >>> kd.cond((x < 0, 2 * x), (x == 0, 3 * x), (x > 0, 5 * x))
    If(x < 0,
       2*x,
       If(x == 0, 3*x, If(x > 0, 5*x, unreachable...)))
    >>> kd.cond((x < 0, 2 * x), (x == 0, 3 * x), default = 5 * x)
    If(x < 0, 2*x, If(x == 0, 3*x, 5*x))
    """
    sort = None
    if default is not None and isinstance(default, smt.ExprRef):
        sort = default.sort()
    else:
        for c, t in cases:
            if not smt.is_bool(c):
                raise Exception("Condition must be boolean", c)
            if isinstance(
                t, smt.ExprRef
            ):  # looping through allows (some_cond , 0) to be a case if z3 will infer what 0 will be
                sort = t.sort()
                break
        if sort is None:
            raise Exception("Could not infer return sort")
    if default is None:
        """ Check totality of cases """
        s = smt.Solver()
        s.add(smt.Not(smt.Or([c for c, t in cases])))
        res = s.check()
        if res == smt.sat:
            raise Exception("Cases not exhaustive. Fix or give default", s.model())
        elif res != smt.unsat:
            raise Exception("Solver error. Give default", res)
        else:
            default = smt.FreshConst(sort, prefix="unreachable")
    acc = default
    for c, t in reversed(cases):
        if isinstance(t, smt.ExprRef) and t.sort() != sort:
            raise Exception("Sort mismatch in cond", t, sort)
        acc = smt.If(c, t, acc)
    return acc


def conde(*cases):
    """
    Minikanren style helper to create an `Or` of `And`s

    >>> x,y = smt.Ints("x y")
    >>> conde((x > 0, y == x + 1), (x < 0, y == x - 1))
    Or(And(x > 0, y == x + 1), And(x < 0, y == x - 1))
    """
    return smt.Or([smt.And(c) for c in cases])


class Cond:
    """
    Imperative class based API to build a chain of if-else statements
    """

    def __init__(self):
        self.cases = []
        self.default = None

    def when(self, cond: smt.BoolRef):
        self.cases.append((cond, None))
        return self

    def then(self, thn: smt.ExprRef):
        self.cases[-1] = (self.cases[-1][0], thn)
        return self

    def otherwise(self, els: smt.ExprRef):
        self.default = els
        return self

    def expr(self) -> smt.ExprRef:
        return cond(*self.cases, default=self.default)
